package com.lagou.client;

import java.util.HashMap;
import java.util.Map;

public class RequestSendServer {
    private static RequestSendServer instance;
    private RequestSendServer() {

    }
    public static RequestSendServer getInstance() {
        if(instance == null)
            instance = new RequestSendServer();
        return instance;
    }

    private Map<String, String> reqSendServerMap = new HashMap<>();//保存处理的server信息

    public Map<String, String> getReqSendServerMap() {
        return reqSendServerMap;
    }

    public void setReqSendServerMap(Map<String, String> reqSendServerMap) {
        this.reqSendServerMap = reqSendServerMap;
    }

}
