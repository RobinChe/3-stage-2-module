package com.lagou.client;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lagou.entity.ServerCostInfo;
import com.lagou.entity.ServerNodeDataEntity;
import com.lagou.service.UserService;
import com.lagou.vo.JSONSerializer;
import com.lagou.vo.RpcEncoder;
import com.lagou.vo.RpcRequest;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;
import io.netty.handler.codec.string.StringDecoder;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class RpcConsumer {

    private static RpcConsumer instance;
    private RpcConsumer() {

    }
    public static synchronized RpcConsumer getInstance() {
        if(instance == null)
            instance = new RpcConsumer();
        return instance;
    }

    //创建线程池对象
    private static ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    //连接服务器列表
    private static List<ConnectionServerInfo> connectionServerList;


    //private static Set<String> nettyAddressSet = new HashSet<String>();

    private static ZooKeeper zkClient;
    private static NettyServerWatcher nettyServerWatcher;
    private static CountDownLatch countDownLatch = new CountDownLatch(1);





    public void initConnNettyServer() throws KeeperException, InterruptedException {
        initClient();
    }

    public Object createProxy(final Class<?> serviceClass) throws KeeperException, InterruptedException {

        //借助JDK动态代理生成代理对象
        return Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class<?>[]{serviceClass}, new InvocationHandler() {
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                //（1）调用初始化netty客户端的方法
                if(connectionServerList == null) {
                    throw new Exception("Not Found Any Server...");
                }

                RpcRequest request = new RpcRequest();
                String requestId = UUID.randomUUID().toString();
                //System.out.println(requestId);

                String className = method.getDeclaringClass().getName();
                String methodName = method.getName();
                Class<?>[] parameterTypes = method.getParameterTypes();//方法参数

                System.out.println("===============" + className);
                request.setRequestId(requestId);
                request.setClassName(className);
                request.setMethodName(methodName);
                request.setParameterTypes(parameterTypes);
                request.setParameters(args);

                //计算nettyServer
                ConnectionServerInfo connectionServerInfo = getConnectionServer(className, connectionServerList);
                if(connectionServerInfo == null)
                    return null;
                System.out.println("计算出来的server为：" + connectionServerInfo.getHost() + ":" + connectionServerInfo.getPort());


                //Random random = new Random();
                //ConnectionServerInfo connectionServerInfo = connectionServerList.get(random.nextInt(connectionServerList.size()));
                //System.out.println("random the server：" + connectionServerInfo.getHost() + ":" + connectionServerInfo.getPort() + " process the request。。。");

                UserClientHandler userClientHandler = connectionServerInfo.getUserClientHandler();

                //保存当前时间
                RequestSendTime.getInstance().getReqSendTimeMap().put(requestId, System.currentTimeMillis());
                //保存关联的服务
                RequestSendServer.getInstance().getReqSendServerMap().put(requestId, connectionServerInfo.getPath());

                // 设置参数
                userClientHandler.setPara(request);
                //去服务端请求数据
                return executor.submit(userClientHandler).get();
            }


        });
    }

    /**
     * 更新服务的耗时时间
     * @param serverPath
     * @param currentTime
     * @param requestTime
     * @param clazz
     * @throws KeeperException
     * @throws InterruptedException
     */
    public void updateServerCostTime(String serverPath, long currentTime, long requestTime, Class<?> clazz) throws KeeperException, InterruptedException {
        System.out.println("服务端路径为：" + serverPath + ", 调用耗时：" + (currentTime - requestTime));

        byte[] childrenData = zkClient.getData(ZookeeperProperties.basePath + "/" + serverPath, false, null);
        String hostAddress = new String(childrenData);
        ServerNodeDataEntity serverNodeData = JSONObject.parseObject(hostAddress, ServerNodeDataEntity.class);

        updateServerNodeData(serverNodeData, currentTime, requestTime, clazz.getName());

        //更新数据
        zkClient.setData(ZookeeperProperties.basePath + "/" + serverPath, JSON.toJSONString(serverNodeData).getBytes(), -1);




        //EventLoopGroup eventLoopGroup = connectionNettyServer(serverNodeData.getHost(), serverNodeData.getPort(), userClientHandler);
        //System.out.println("netty服务:" + serverNodeData.getHost() + ":" + serverNodeData.getPort() + "连接成功!!!");
        //
        //ConnectionServerInfo serverInfo = new ConnectionServerInfo();
        //serverInfo.setPath(childrenPath);
        //serverInfo.setHost(serverNodeData.getHost());
        //serverInfo.setPort(serverNodeData.getPort());
        //serverInfo.setServerCostInfos(serverNodeData.getServerCostList());
        //serverInfo.setUserClientHandler(userClientHandler);
        //serverInfo.setGroup(eventLoopGroup);
        //connectionServerList.add(serverInfo);

    }

    private void updateServerNodeData(ServerNodeDataEntity serverNodeData, long currentTime, long requestTime, String clazzName) {
        List<ServerCostInfo> serverCostList = serverNodeData.getServerCostList();
        for (ServerCostInfo costInfo : serverCostList) {
            if(clazzName.equals(costInfo.getServerName())) {
                costInfo.setCostTime(currentTime - requestTime);
                costInfo.setLastTransferTime(currentTime);
                break;
            }
        }
        serverNodeData.setServerCostList(serverCostList);

    }

    public static void main(String[] args) {
        System.out.println(UserService.class.getName());
    }





    private ConnectionServerInfo getConnectionServer(String className, List<ConnectionServerInfo> connectionServerList) {
        List<ConnectionServerInfo> list = getMinCostTime(className, connectionServerList);
        if(list.size() == 1)
            return list.get(0);
        if(list.size() > 1) {
            Random random = new Random();
            return list.get(random.nextInt(list.size()));
        }
        return null;
    }

    /**
     * 计算得出耗时最小的一组server
     * @param className
     * @param connectionServerList
     * @return
     */
    private List<ConnectionServerInfo> getMinCostTime(String className, List<ConnectionServerInfo> connectionServerList) {

        List<ConnectionServerInfo> minCostList = new ArrayList<>();

        long costTime = 0l;
        for (int i = 0; i < connectionServerList.size(); i++) {
            ConnectionServerInfo info = connectionServerList.get(i);
            List<ServerCostInfo> serverCostInfos = info.getServerCostInfos();

            ServerCostInfo costInfo = getServerCostInfo(className, serverCostInfos);
            if(costInfo != null) {
                if(!costInfo.isActive()) {//超时或失效，响应时间清零
                    minCostList.clear();
                    costTime = 0l;
                    minCostList.add(info);
                    System.out.println("server=" + info.getHost() + ", port=" + info.getPort() + "超时或失效，响应时间清零");
                } else {
                    if(minCostList.size() == 0) {
                        costTime = costInfo.getCostTime();
                        minCostList.add(info);
                    } else {
                        if(costInfo.getCostTime() < costTime ) {//时间小，要清空之前的list，并保留到list中
                            minCostList.clear();
                            costTime = costInfo.getCostTime();
                            minCostList.add(info);
                        } else if (costInfo.getCostTime() == costTime) {//耗时时间相等，直接保存到list
                            minCostList.add(info);
                        }
                    }
                }
            }
        }
        return minCostList;
    }

    private ServerCostInfo getServerCostInfo(String className, List<ServerCostInfo> serverCostInfos) {
        if (serverCostInfos == null || serverCostInfos.size() == 0)
            return null;
        for (ServerCostInfo info : serverCostInfos) {
            if(className.equals(info.getServerName()))
                return info;
        }
        return null;
    }


    //2.初始化netty客户端
    private static  void initClient() throws InterruptedException, KeeperException {

        //bootstrap.connect("127.0.0.1",8990).sync();

        if (zkClient == null)
            connectionZk();

        /*connectionServerList = new ArrayList<ConnectionServerInfo>();
        List<String> children = zkClient.getChildren(ZookeeperProperties.basePath, true);

        if(children == null || children.size() == 0)
            return;

        for (String childrenPath : children) {
            getChildrenDataAndConnectionNetty(childrenPath);
        }*/


    }

    private static void getChildrenDataAndConnectionNetty(String childrenPath) throws KeeperException, InterruptedException {
        byte[] childrenData = zkClient.getData(ZookeeperProperties.basePath + "/" + childrenPath, false, null);
        String hostAddress = new String(childrenData);

        UserClientHandler userClientHandler = new UserClientHandler();

        //JSONObject jsonObject = JSON.parseObject(hostAddress);
        //String host = jsonObject.getString("host");
        //Integer port = jsonObject.getIntValue("port");
        ServerNodeDataEntity serverNodeData = JSONObject.parseObject(hostAddress, ServerNodeDataEntity.class);


        EventLoopGroup eventLoopGroup = connectionNettyServer(serverNodeData.getHost(), serverNodeData.getPort(), userClientHandler);
        System.out.println("netty服务:" + serverNodeData.getHost() + ":" + serverNodeData.getPort() + "连接成功!!!");

        ConnectionServerInfo serverInfo = new ConnectionServerInfo();
        serverInfo.setPath(childrenPath);
        serverInfo.setHost(serverNodeData.getHost());
        serverInfo.setPort(serverNodeData.getPort());
        serverInfo.setServerCostInfos(serverNodeData.getServerCostList());
        serverInfo.setUserClientHandler(userClientHandler);
        serverInfo.setGroup(eventLoopGroup);
        connectionServerList.add(serverInfo);
    }




    public static class NettyServerWatcher implements Watcher {

        @Override
        public void process(WatchedEvent watchedEvent) {
            if(Event.KeeperState.SyncConnected==watchedEvent.getState()){
                if(Event.EventType.None == watchedEvent.getType()) {
                    //如果收到了服务端的响应事件,连接成功
                    System.out.println("zookeeper连接成功!!!!");
                    try {
                        connectionServerList = new ArrayList<ConnectionServerInfo>();
                        List<String> children = zkClient.getChildren(ZookeeperProperties.basePath, true);
                        if(children == null || children.size() == 0)
                            return;

                        for (String childrenPath : children) {
                            getChildrenDataAndConnectionNetty(childrenPath);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        countDownLatch.countDown();
                    }

                }
                else if(Event.EventType.NodeChildrenChanged == watchedEvent.getType()) {
                    System.out.println("watch the node children changed....");
                    try {
                        List<String> children_new = zkClient.getChildren(ZookeeperProperties.basePath, true);

                        //机器全部下线
                        if(children_new == null || children_new.size() == 0) {
                            if(connectionServerList != null && connectionServerList.size() > 0) {
                                shoutdownNettyServer(connectionServerList);
                            }
                            return;
                        }


                        //是否有机器下线
                        List<ConnectionServerInfo> offlineServers = connectionServerList.stream().filter(info -> {
                            for (String childrenPath : children_new) {
                                if(info.getPath().equals(childrenPath))
                                    return false;
                            }
                            return true;
                        }).collect(Collectors.toList());

                        if(offlineServers != null && offlineServers.size() > 0)
                            shoutdownNettyServer(offlineServers);


                        //是否有机器上线
                        List<String> onlineServers = children_new.stream().filter(path -> {
                            for(ConnectionServerInfo info : connectionServerList) {
                                if(path.equals(info.getPath()))
                                    return false;
                            }
                            return true;
                        }).collect(Collectors.toList());
                        if(onlineServers != null && onlineServers.size() > 0) {
                            for (String children : onlineServers) {
                                getChildrenDataAndConnectionNetty(children);
                            }
                        }
                    } catch (KeeperException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

            }
        }

        private void shoutdownNettyServer(List<ConnectionServerInfo> shutdownServerList) {
            shutdownServerList.forEach(connectionInfo -> {
                try {
                    EventLoopGroup group = connectionInfo.getGroup();
                    group.shutdownGracefully();
                    System.out.println("netty服务:" + connectionInfo.getHost() + ":" + connectionInfo.getPort() + "成功断开连接！！！");
                }catch (Exception e) {
                }
            });
            //移除关闭连接的服务
            connectionServerList = connectionServerList.stream().filter(connServer -> {
                for (ConnectionServerInfo shutdownServer : shutdownServerList) {
                    if(connServer.getPath().equals(shutdownServer.getPath())) {
                        return false;
                    }
                }
                return true;
            }).collect(Collectors.toList());

        }
    }

    /**
     * 客户端连接服务器信息
     */
    public static class ConnectionServerInfo  {

        public ConnectionServerInfo() {

        }
        private String path;
        private String host;
        private Integer port;
        //增加连接服务端的耗时时间对象
        private List<ServerCostInfo> serverCostInfos;

        private UserClientHandler userClientHandler;
        private EventLoopGroup group;

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public Integer getPort() {
            return port;
        }

        public void setPort(Integer port) {
            this.port = port;
        }

        public List<ServerCostInfo> getServerCostInfos() {
            return serverCostInfos;
        }

        public void setServerCostInfos(List<ServerCostInfo> serverCostInfos) {
            this.serverCostInfos = serverCostInfos;
        }

        public UserClientHandler getUserClientHandler() {
            return userClientHandler;
        }

        public void setUserClientHandler(UserClientHandler userClientHandler) {
            this.userClientHandler = userClientHandler;
        }

        public EventLoopGroup getGroup() {
            return group;
        }

        public void setGroup(EventLoopGroup group) {
            this.group = group;
        }
    }


    public static EventLoopGroup connectionNettyServer(String host, Integer port, final UserClientHandler userClientHandler) throws InterruptedException {
        EventLoopGroup group = new NioEventLoopGroup();
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(group)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.TCP_NODELAY,true)
                .handler(new ChannelInitializer<SocketChannel>() {
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new RpcEncoder(RpcRequest.class, new JSONSerializer()));
                        pipeline.addLast(new StringDecoder());
                        pipeline.addLast(userClientHandler);
                    }
                });
        bootstrap.connect(host, port).sync();
        return group;
    }



    public static void connectionZk() {
        try {
            nettyServerWatcher = new NettyServerWatcher();
            //连接成功后，会回调watcher监听，此连接操作是异步的，执行完new语句后，直接调用后续代码
            //  可指定多台服务地址 127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183
            zkClient = new ZooKeeper(ZookeeperProperties.connectString, ZookeeperProperties.timeout, nettyServerWatcher);
            System.out.println("【客户端初始化ZooKeeper连接状态....】=" + zkClient.getState());
            countDownLatch.await();

        }catch (Exception e){
            System.out.println("客户端初始化ZooKeeper连接异常....】="  + e);
        }
    }


}
