package com.clb.zookeeper.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.clb.zookeeper.entity.DataSourceEntity;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class SpringUtils implements ApplicationContextAware {

    private static ApplicationContext applicationContext;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        System.out.println("获取applicationContext....");
        SpringUtils.applicationContext = applicationContext;
    }

    public static <T> T getBean(String beanName) {
        if(applicationContext.containsBean(beanName)){
            return (T) applicationContext.getBean(beanName);
        }else{
            return null;
        }
    }


    /**
     * 动态注入bean
     * @param beanName
     * @param sourceEntity
     */
    public static void registerDataSourceBean(String beanName, DataSourceEntity sourceEntity) {

        //获取BeanFactory
        DefaultListableBeanFactory defaultListableBeanFactory = (DefaultListableBeanFactory)applicationContext.getAutowireCapableBeanFactory();

        //删除bean.
        defaultListableBeanFactory.removeBeanDefinition(beanName);

        //创建bean信息
        BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(DruidDataSource.class);
        beanDefinitionBuilder.addPropertyValue("url",sourceEntity.getUrl());
        beanDefinitionBuilder.addPropertyValue("driverClassName",sourceEntity.getDriverClassName());
        beanDefinitionBuilder.addPropertyValue("username",sourceEntity.getUsername());
        beanDefinitionBuilder.addPropertyValue("password",sourceEntity.getPassword());
        //beanDefinitionBuilder.addPropertyValue("jdbcUrl",sourceEntity.getUrl());
        //beanDefinitionBuilder.addPropertyValue("driverClass",sourceEntity.getDriverClassName());
        //beanDefinitionBuilder.addPropertyValue("user",sourceEntity.getUsername());
        //beanDefinitionBuilder.addPropertyValue("password",sourceEntity.getPassword());


        //动态注册bean
        defaultListableBeanFactory.registerBeanDefinition(beanName,beanDefinitionBuilder.getBeanDefinition());

    }





    public static <T> Map<String, T> getBeansOfType(Class<T> baseType){
        return applicationContext.getBeansOfType(baseType);
    }

    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }
}

