package com.clb.zookeeper.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.fastjson.JSON;
import com.clb.zookeeper.entity.DataSourceEntity;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Value("${mysql.datasource.url}")
    private String url;

    @Value("${mysql.datasource.driver-class-name}")
    private String driverClassName;

    @Value("${mysql.datasource.username}")
    private String username;

    @Value("${mysql.datasource.password}")
    private String password;

    @Autowired
    private ZooKeeper zkClient;

    @Value("${zookeeper.datasource.config}")
    private String dataBaseConfigPath;

    @Bean(name = "dataSource")
    public DataSource dataSource() throws Exception {
        /*c3p0连接池*/
        //ComboPooledDataSource dataSource = new ComboPooledDataSource();
        //dataSource.setJdbcUrl(url);
        //dataSource.setDriverClass(driverClassName);
        //dataSource.setUser(username);
        //dataSource.setPassword(password);
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setUrl(url);
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUsername(username);
        dataSource.setPassword(password);

        DataSourceEntity sourceEntity = new DataSourceEntity();
        sourceEntity.setUrl(url);
        sourceEntity.setDriverClassName(driverClassName);
        sourceEntity.setUsername(username);
        sourceEntity.setPassword(password);
        processZookeeper(sourceEntity);

        System.out.println("数据库连接成功!....");
        return dataSource;
    }




    private void processZookeeper(DataSourceEntity sourceEntity) throws KeeperException, InterruptedException {

        String pathData = JSON.toJSONString(sourceEntity);
        Stat stat = zkClient.exists(dataBaseConfigPath, false);
        if(stat == null)
            zkClient.create(dataBaseConfigPath, pathData.getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        else
            zkClient.setData(dataBaseConfigPath, pathData.getBytes(), -1);


        byte[] data = zkClient.getData(dataBaseConfigPath, true, null);
        String mysqlConfig = new String(data);
        System.out.println("zookeeper上配置的数据库信息为:" + mysqlConfig);
    }

}
