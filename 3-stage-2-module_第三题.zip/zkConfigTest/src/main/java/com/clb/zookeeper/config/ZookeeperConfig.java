package com.clb.zookeeper.config;


import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.fastjson.JSON;
import com.clb.zookeeper.entity.DataSourceEntity;
import com.clb.zookeeper.utils.SpringUtils;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.CountDownLatch;

@Configuration
public class ZookeeperConfig {

    private Logger logger = LoggerFactory.getLogger(ZookeeperConfig.class);

    @Value("${zookeeper.address}")
    private    String connectString;
    @Value("${zookeeper.timeout}")
    private  int timeout;
    @Value("${zookeeper.datasource.config}")
    private String dataBaseConfigPath;

    private CountDownLatch countDownLatch = new CountDownLatch(1);
    ZooKeeper zooKeeper=null;



    @Bean(name = "zkClient")
    public ZooKeeper zkClient(){

        try {
            //连接成功后，会回调watcher监听，此连接操作是异步的，执行完new语句后，直接调用后续代码
            //  可指定多台服务地址 127.0.0.1:2181,127.0.0.1:2182,127.0.0.1:2183
            zooKeeper = new ZooKeeper(connectString, timeout, new ZkWatch());
            countDownLatch.await();
            logger.info("【初始化ZooKeeper连接状态....】={}",zooKeeper.getState());

        }catch (Exception e){
            logger.error("初始化ZooKeeper连接异常....】={}",e);
        }
        return  zooKeeper;
    }


    public class ZkWatch implements Watcher {

        @Override
        public void process(WatchedEvent event) {
            if(Event.KeeperState.SyncConnected==event.getState()){
                if(Event.EventType.None == event.getType()) {
                    //如果收到了服务端的响应事件,连接成功
                    countDownLatch.countDown();
                    logger.info("连接zookeeper成功...");
                }
                else if(Event.EventType.NodeDataChanged == event.getType()) {
                    logger.info("watch the nodeData hanppen changed...");
                    try {
                        byte[] data = zooKeeper.getData(dataBaseConfigPath, true, null);
                        String mysqlConfig = new String(data);
                        logger.info("数据库配置信息更新为:" + mysqlConfig);


                        DruidDataSource druidDataSource = SpringUtils.getBean("dataSource");
                        druidDataSource.close();

                        DataSourceEntity sourceEntity = JSON.parseObject(mysqlConfig, DataSourceEntity.class);
                        SpringUtils.registerDataSourceBean("dataSource", sourceEntity);

                        DruidDataSource druidDataSourceNew = SpringUtils.getBean("dataSource");
                        String url = druidDataSourceNew.getUrl();
                        logger.info("新的数据库url=" + url);

                        //ComboPooledDataSource druidDataSource = SpringUtils.getBean("dataSource");
                        //druidDataSource.close();
                        //druidDataSource.clearStatementCache();
                        //druidDataSource.setUrl("jdbc:mysql://localhost:3306/bank?useUnicode=true&characterEncoding=utf-8&allowMultiQueries=true&useSSL=false&serverTimezone=Asia/Shanghai");
                        //druidDataSource.setDriverClassName(sourceEntity.getDriverClassName());
                        ////druidDataSource.setUrl(sourceEntity.getUrl());
                        //druidDataSource.setUsername(sourceEntity.getUsername());
                        //druidDataSource.setPassword(sourceEntity.getPassword());
                        //druidDataSource.restart();
                        logger.info("数据源重新加载成功!.....");

                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }
            }
        }
    }

}
