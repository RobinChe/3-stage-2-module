package com.lagou.client;

import com.lagou.service.UserService;
import org.apache.zookeeper.KeeperException;

public class ClientBootStrap {
    //public static  final String providerName="UserService#sayHello#";

    public static void main(String[] args) throws InterruptedException, KeeperException {


        RpcConsumer rpcConsumer = RpcConsumer.getInstance();
        rpcConsumer.initConnNettyServer();//初始化netty连接

        UserService proxy = (UserService) rpcConsumer.createProxy(UserService.class);

        while (true){
            try {
                Thread.sleep(3000);
                /*String requestId = proxy.sayHello("are you ok?");
                System.out.println("响应的数据：requestId:" + requestId);
                long currentTime = System.currentTimeMillis();
                long requestTime = RequestSendTime.getInstance().getReqSendTimeMap().get(requestId);

                String serverPath = RequestSendServer.getInstance().getReqSendServerMap().get(requestId);

                //更新消耗时间
                rpcConsumer.updateServerCostTime(serverPath, currentTime, requestTime, UserService.class);*/
            } catch (Exception e) {
                e.printStackTrace();
            }



        }


    }
}
