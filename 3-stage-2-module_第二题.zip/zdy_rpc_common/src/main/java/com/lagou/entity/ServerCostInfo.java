package com.lagou.entity;

public class ServerCostInfo {

    private String serverName;
    private long lastTransferTime;
    private long costTime;

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public long getLastTransferTime() {
        return lastTransferTime;
    }

    public void setLastTransferTime(long lastTransferTime) {
        this.lastTransferTime = lastTransferTime;
    }

    public long getCostTime() {
        return costTime;
    }

    public void setCostTime(long costTime) {
        this.costTime = costTime;
    }

    public boolean isActive() {
        if(lastTransferTime + 5 * 1000 > System.currentTimeMillis())
            return false;
        return true;
    }
}
