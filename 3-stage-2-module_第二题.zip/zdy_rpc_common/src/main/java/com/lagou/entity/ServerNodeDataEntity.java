package com.lagou.entity;

import java.util.List;

public class ServerNodeDataEntity {

    private String host;
    private Integer port;
    private List<ServerCostInfo> serverCostList;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public List<ServerCostInfo> getServerCostList() {
        return serverCostList;
    }

    public void setServerCostList(List<ServerCostInfo> serverCostList) {
        this.serverCostList = serverCostList;
    }
}
