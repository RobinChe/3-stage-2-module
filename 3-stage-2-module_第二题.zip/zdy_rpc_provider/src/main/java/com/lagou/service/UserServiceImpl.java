package com.lagou.service;

import com.alibaba.fastjson.JSONObject;
import com.lagou.entity.ServerCostInfo;
import com.lagou.entity.ServerNodeDataEntity;
import com.lagou.handler.UserServerHandler;
import com.lagou.vo.JSONSerializer;
import com.lagou.vo.RpcDecoder;
import com.lagou.vo.RpcRequest;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.string.StringEncoder;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private ZooKeeper zkClient;

    @Value("${netty.address}")
    private String hostName;
    @Value("${netty.port}")
    private int port;

    @Value("${zookeeper.basePath}")
    private String basePath;

    @Override
    public String sayHello(String word) {
        System.out.println("调用成功--参数 "+word);
        return "调用成功--参数 "+word;
    }

    @PostConstruct
    public void init() throws Exception {
        startNettyServer(hostName, port);
        registe2Zookeeper(hostName, port);
    }

    //hostName:ip地址  port:端口号
    public void startNettyServer(String hostName,int port) throws InterruptedException {

        NioEventLoopGroup bossGroup = new NioEventLoopGroup();
        NioEventLoopGroup workerGroup = new NioEventLoopGroup();

        ServerBootstrap serverBootstrap = new ServerBootstrap();
        serverBootstrap.group(bossGroup,workerGroup)
                .channel(NioServerSocketChannel.class)
                .childHandler(new ChannelInitializer<SocketChannel>() {
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new StringEncoder());
                        pipeline.addLast(new RpcDecoder(RpcRequest.class, new JSONSerializer()));
                        pipeline.addLast(new UserServerHandler());

                    }
                });
        System.out.println("started netty server on port ：" + port + " success...");
        serverBootstrap.bind(hostName,port).sync();
    }

    public void registe2Zookeeper(String hostName,int port) throws KeeperException, InterruptedException {
        Stat state = zkClient.exists(basePath, false);
        if(state == null)
            zkClient.create(basePath, "rpc_node".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);

        ServerNodeDataEntity nodeDataEntity = new ServerNodeDataEntity();
        nodeDataEntity.setHost(hostName);
        nodeDataEntity.setPort(port);


        ServerCostInfo serverCost = new ServerCostInfo();
        serverCost.setServerName(UserService.class.getName());
        serverCost.setCostTime(0);
        serverCost.setLastTransferTime(0);
        List<ServerCostInfo> costInfoList = new ArrayList<>();
        costInfoList.add(serverCost);
        nodeDataEntity.setServerCostList(costInfoList);

        zkClient.create(basePath + "/" + hostName + "_" + port, JSONObject.toJSONString(nodeDataEntity).getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
    }

    public static void main(String[] args) {
        System.out.println(UserService.class.getName());
    }
}
