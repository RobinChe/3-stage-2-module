package com.lagou.client;

public class ZookeeperProperties {

    //public static final String connectString = "119.28.226.31:2181";
    public static final String connectString = "127.0.0.1:2181";
    public static final int timeout = 30000;

    public static final String basePath="/rpc_provider";
}
