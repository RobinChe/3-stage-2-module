package com.lagou.client;

import java.util.HashMap;
import java.util.Map;

public class RequestSendTime {
    private static RequestSendTime instance;
    private RequestSendTime() {

    }
    public static RequestSendTime getInstance() {
        if(instance == null)
            instance = new RequestSendTime();
        return instance;
    }

    private Map<String, Long> reqSendTimeMap = new HashMap<>();//保存发送时间

    public Map<String, Long> getReqSendTimeMap() {
        return reqSendTimeMap;
    }

    public void setReqSendTimeMap(Map<String, Long> reqSendTimeMap) {
        this.reqSendTimeMap = reqSendTimeMap;
    }
}
