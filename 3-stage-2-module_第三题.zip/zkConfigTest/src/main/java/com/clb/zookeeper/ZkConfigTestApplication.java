package com.clb.zookeeper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZkConfigTestApplication {
    public static void main(String[] args) {
        SpringApplication.run(ZkConfigTestApplication.class, args);
    }
}
